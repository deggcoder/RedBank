package itso.rad80.bank.exception;

public class ITSOBankException extends Exception {
	
	private static final long serialVersionUID = 2193871932402565820L;

	public ITSOBankException(String message) {
		super(message);
	}
	
}
