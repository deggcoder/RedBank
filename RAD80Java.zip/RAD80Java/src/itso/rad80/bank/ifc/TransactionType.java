package itso.rad80.bank.ifc;

import java.lang.String;

public interface TransactionType {

	public String CREDIT = "CREDIT";
	public String DEBIT = "DEBIT";

}
